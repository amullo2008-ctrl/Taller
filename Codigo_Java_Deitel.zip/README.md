# Ejercicios Java - Deitel capitulo 3

Cinco ejercicios de POO: Factura, Empleado, Fecha, FrecuenciasCardiacas y PerfilMedico.

Para ejecutar cada uno, entra a su carpeta y utiliza `javac *.java` y `java PruebaNombreClase`.

Nota: calculos cardiacos e IMC solo para practica academica.
